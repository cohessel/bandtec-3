public interface Empresa {
    public double getBonus();
}
