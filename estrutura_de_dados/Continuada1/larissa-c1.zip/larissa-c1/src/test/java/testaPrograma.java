public class testaPrograma {
    public static void main(String[] args) {

    }
}
