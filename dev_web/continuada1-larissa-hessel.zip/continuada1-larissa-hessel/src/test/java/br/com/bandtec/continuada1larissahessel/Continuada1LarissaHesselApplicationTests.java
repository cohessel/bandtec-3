package br.com.bandtec.continuada1larissahessel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Continuada1LarissaHesselApplicationTests {

	@Test
	void contextLoads() {
	}

}
