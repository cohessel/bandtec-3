package br.com.bandtec.continuada1larissahessel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Continuada1LarissaHesselApplication {

	public static void main(String[] args) {
		SpringApplication.run(Continuada1LarissaHesselApplication.class, args);
	}

}
